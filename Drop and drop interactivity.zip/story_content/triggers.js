function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6f2MATNaKD7":
        Script1();
        break;
      case "6ZeXbvR03LM":
        Script2();
        break;
      case "5YWnAObwRH6":
        Script3();
        break;
      case "5ypteU1CEaA":
        Script4();
        break;
      case "5l7jnSOcWKI":
        Script5();
        break;
      case "6nLQ5C1Jc7A":
        Script6();
        break;
      case "5o0UmGzJYpw":
        Script7();
        break;
      case "5mTxhgEYZAc":
        Script8();
        break;
      case "6Vjt9uUfVTW":
        Script9();
        break;
      case "6EvPDllDQjs":
        Script10();
        break;
      case "6XWymzgRxGU":
        Script11();
        break;
      case "5m4yzdCp1LF":
        Script12();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var once = player.once;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
var update = player.update;
var pointerX = player.pointerX;
var pointerY = player.pointerY;
var showPointer = player.showPointer;
var hidePointer = player.hidePointer;
var slideWidth = player.slideWidth;
var slideHeight = player.slideHeight;
var getKeyDown = player.getKeyDown;
var keydown = player.keydown;
var keyup = player.keyup;
window.Script1 = function()
{
  const target = object('6eP3L9fNKDl');
const duration = 250;
const easing = 'ease-out';
const id = '68FNtWeTrqg';
const growAmount = 0.1;
player.addForTriggers(
id,
target.animate(
[ {scale: `${1 + growAmount}` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script2 = function()
{
  const target = object('6eP3L9fNKDl');
const duration = 250;
const easing = 'ease-out';
const id = '68FNtWeTrqg_reverse';
const growAmount = 0;
player.addForTriggers(
id,
target.animate(
[ {scale: `${1 + growAmount}` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script3 = function()
{
  const target = object('6VYUXlyZ0oS');
const duration = 250;
const easing = 'ease-out';
const id = '6qLSif3vyNx';
const growAmount = 0.1;
player.addForTriggers(
id,
target.animate(
[ {scale: `${1 + growAmount}` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script4 = function()
{
  const target = object('6VYUXlyZ0oS');
const duration = 250;
const easing = 'ease-out';
const id = '6qLSif3vyNx_reverse';
const growAmount = 0;
player.addForTriggers(
id,
target.animate(
[ {scale: `${1 + growAmount}` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script5 = function()
{
  const target = object('6rYZZ0SjWAw');
const duration = 250;
const easing = 'ease-out';
const id = '69znb7FsYZd';
const growAmount = 0.1;
player.addForTriggers(
id,
target.animate(
[ {scale: `${1 + growAmount}` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script6 = function()
{
  const target = object('6rYZZ0SjWAw');
const duration = 250;
const easing = 'ease-out';
const id = '69znb7FsYZd_reverse';
const growAmount = 0;
player.addForTriggers(
id,
target.animate(
[ {scale: `${1 + growAmount}` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script7 = function()
{
  const target = object('5qF7bJZVvN8');
const duration = 250;
const easing = 'ease-out';
const id = '6MN9uLppNES';
const growAmount = 0.1;
player.addForTriggers(
id,
target.animate(
[ {scale: `${1 + growAmount}` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script8 = function()
{
  const target = object('5qF7bJZVvN8');
const duration = 250;
const easing = 'ease-out';
const id = '6MN9uLppNES_reverse';
const growAmount = 0;
player.addForTriggers(
id,
target.animate(
[ {scale: `${1 + growAmount}` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script9 = function()
{
  const target = object('5eOmH0gE02K');
const duration = 250;
const easing = 'ease-out';
const id = '6oyiWJTWbRJ';
const growAmount = 0.1;
player.addForTriggers(
id,
target.animate(
[ {scale: `${1 + growAmount}` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script10 = function()
{
  const target = object('5eOmH0gE02K');
const duration = 250;
const easing = 'ease-out';
const id = '6oyiWJTWbRJ_reverse';
const growAmount = 0;
player.addForTriggers(
id,
target.animate(
[ {scale: `${1 + growAmount}` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script11 = function()
{
  const target = object('685lhMZjtr9');
const duration = 250;
const easing = 'ease-out';
const id = '69c2IOKS716';
const growAmount = 0.1;
player.addForTriggers(
id,
target.animate(
[ {scale: `${1 + growAmount}` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

window.Script12 = function()
{
  const target = object('685lhMZjtr9');
const duration = 250;
const easing = 'ease-out';
const id = '69c2IOKS716_reverse';
const growAmount = 0;
player.addForTriggers(
id,
target.animate(
[ {scale: `${1 + growAmount}` } ]
,
  { fill: 'forwards', duration, easing }
)
);
}

};
