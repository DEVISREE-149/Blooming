window.InitUserScripts = function()
{
var player = GetPlayer();
var object = player.object;
var once = player.once;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
var update = player.update;
var pointerX = player.pointerX;
var pointerY = player.pointerY;
var showPointer = player.showPointer;
var hidePointer = player.hidePointer;
var slideWidth = player.slideWidth;
var slideHeight = player.slideHeight;
var getKeyDown = player.getKeyDown;
var keydown = player.keydown;
var keyup = player.keyup;
window.Script1 = function()
{
  // Load confetti.js if not already loaded



if (typeof confetti === "undefined") {



  const script = document.createElement("script");



  script.src = "https://cdn.jsdelivr.net/npm/canvas-confetti@1.6.0/dist/confetti.browser.min.js";



  script.onload = triggerConfetti;



  document.head.appendChild(script);



} else {



  triggerConfetti();



}







function triggerConfetti() {



  // Create a full-screen canvas



  const canvas = document.createElement("canvas");



  canvas.id = "confetti-canvas";



  canvas.style.position = "absolute";



  canvas.style.top = "0";



  canvas.style.left = "0";



  canvas.style.width = "100%";



  canvas.style.height = "100%";



  canvas.style.pointerEvents = "none";



  canvas.style.zIndex = "2147483647"; // Stay on top of everything







  // Append to fullscreen element if in fullscreen, otherwise to body



  const fullscreenElement = document.fullscreenElement || document.body;



  fullscreenElement.appendChild(canvas);







  // Create a confetti instance



  const myConfetti = confetti.create(canvas, {



    resize: true,



    useWorker: true



  });







  // Wait for layout to settle



  setTimeout(() => {



    // Try to locate the Storyline slide container



    const slide = document.querySelector(".slide-container, #slide, .slide, .presentation");



    const rect = slide ? slide.getBoundingClientRect() : {



      left: window.innerWidth / 2,



      top: window.innerHeight / 2,



      width: 0,



      height: 0



    };







    // Fire confetti from the center of the Storyline slide



    myConfetti({



      particleCount: 100,



      spread: 95,



      origin: {



        x: (rect.left + rect.width / 2) / window.innerWidth,



        y: (rect.top + rect.height / 2) / window.innerHeight



      }



    });







    // Optional: remove canvas after 3 seconds



    setTimeout(() => {



      canvas.remove();



    }, 3000);



  }, 100); // delay to ensure layout is ready



}
}

};
